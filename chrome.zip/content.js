chrome.browserAction.onClicked.addListener(function(tab) {
  alert('Linkly');
});
// chrome.tabs.executeScript(
//   tab.id,
//   {code: 'alert("Linkly");'
// });
